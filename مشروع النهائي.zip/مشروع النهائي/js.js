

   function Onclick(){
  alert("wellcome to my project")}
 
function onmouselEave(){
document.getElementById("text").style.Color="green";}
function oncliCk(){
document.getElementById("demo").innerHTML="hi doctor"}

function onmousemOve(){
    document.getElementById("demo").style.backgroundColor="blue";}
    function onmouseMove(){
    document.getElementById("text").style.backgroundColor="yellow";}
 
    